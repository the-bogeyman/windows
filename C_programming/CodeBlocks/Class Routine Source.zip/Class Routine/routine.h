int get_day(void);
void show_routine(int day_num);
void print_error(void);
void print_start_msg(void);
void show_full_routine(void);
void routine_header(void);
